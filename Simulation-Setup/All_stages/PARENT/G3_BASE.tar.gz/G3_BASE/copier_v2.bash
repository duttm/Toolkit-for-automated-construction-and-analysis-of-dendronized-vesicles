#!/bin/bash

mkdir vesicle

cp 12-input.gro  system.top vesicle/




